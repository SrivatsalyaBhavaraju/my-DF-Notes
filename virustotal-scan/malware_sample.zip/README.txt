This is a harmless placeholder. Do NOT upload real malware to GitHub.
